import Navbar from '@/components/navbar'
import HeroSection from '@/components/hero-section'
import ProjectsSection from '@/components/projects-section'
import AboutSection from '@/components/about-section'
import SkillsSection from '@/components/skills-section'
import TestimonialsSection from '@/components/testimonials-section'
import ContactSection from '@/components/contact-section'
import Footer from '@/components/footer'

export default function Home() {
  return (
    <main className="min-h-screen bg-white text-black">
      <Navbar />
      <HeroSection />
      <ProjectsSection />
      <AboutSection />
      <SkillsSection />
      <TestimonialsSection />
      <ContactSection />
      <Footer />
    </main>
  )
}
