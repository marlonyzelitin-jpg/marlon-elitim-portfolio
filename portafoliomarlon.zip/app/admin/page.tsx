'use client'

import { useState, useEffect, useCallback } from 'react'
import { useRouter } from 'next/navigation'
import {
  Brush, LayoutDashboard, FolderKanban, Settings,
  LogOut, Plus, Pencil, Trash2, Star, Eye,
  ExternalLink, BarChart2, Palette, ChevronRight
} from 'lucide-react'
import {
  getProjects, createProject, updateProject, deleteProject,
  getSettings, logout, type Project, type SiteSettings
} from '@/lib/store'
import { useAdminGuard } from '@/hooks/use-admin-guard'
import ProjectForm from '@/components/admin/project-form'
import SettingsForm from '@/components/admin/settings-form'

type Tab = 'dashboard' | 'projects' | 'settings'

export default function AdminPage() {
  const ready = useAdminGuard()
  const router = useRouter()
  const [tab, setTab] = useState<Tab>('dashboard')
  const [projects, setProjects] = useState<Project[]>([])
  const [settings, setSettings] = useState<SiteSettings | null>(null)
  const [showForm, setShowForm] = useState(false)
  const [editTarget, setEditTarget] = useState<Project | null>(null)
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null)

  const reload = useCallback(() => {
    setProjects(getProjects())
    setSettings(getSettings())
  }, [])

  useEffect(() => {
    if (ready) reload()
  }, [ready, reload])

  const handleLogout = () => {
    logout()
    router.push('/admin/login')
  }

  const handleSave = (data: Omit<Project, 'id' | 'order'>) => {
    if (editTarget) {
      updateProject(editTarget.id, data)
    } else {
      createProject(data)
    }
    reload()
    setShowForm(false)
    setEditTarget(null)
  }

  const handleDelete = (id: string) => {
    deleteProject(id)
    reload()
    setDeleteConfirm(null)
  }

  const openEdit = (p: Project) => {
    setEditTarget(p)
    setShowForm(true)
  }

  const openNew = () => {
    setEditTarget(null)
    setShowForm(true)
  }

  if (!ready) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <span className="w-8 h-8 border-2 border-teal-400 border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  const designCount = projects.filter((p) => p.discipline === 'design' || p.discipline === 'both').length
  const dataCount = projects.filter((p) => p.discipline === 'data' || p.discipline === 'both').length
  const featuredCount = projects.filter((p) => p.featured).length

  const navItems: { id: Tab; label: string; icon: React.ElementType }[] = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'projects', label: 'Proyectos', icon: FolderKanban },
    { id: 'settings', label: 'Configuracion', icon: Settings },
  ]

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <aside className="w-60 bg-white border-r border-gray-100 flex flex-col fixed left-0 top-0 h-full z-40 shadow-sm">
        {/* Logo */}
        <div className="flex items-center gap-2.5 px-5 py-5 border-b border-gray-100">
          <div className="flex items-center justify-center w-9 h-9 rounded-xl bg-teal-500 text-white shadow">
            <Brush size={16} />
          </div>
          <div>
            <p className="font-bold text-sm text-black leading-none">Marlon Elitim</p>
            <p className="text-xs text-gray-400 mt-0.5">Panel Admin</p>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 px-3 py-4 flex flex-col gap-1">
          {navItems.map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setTab(id)}
              className={`w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium transition-all ${
                tab === id
                  ? 'bg-teal-50 text-teal-700 border border-teal-100'
                  : 'text-gray-600 hover:bg-gray-50 hover:text-black'
              }`}
            >
              <Icon size={17} />
              {label}
            </button>
          ))}

          <div className="border-t border-gray-100 mt-3 pt-3">
            <a
              href="/"
              target="_blank"
              rel="noopener noreferrer"
              className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium text-gray-600 hover:bg-gray-50 hover:text-black transition-all"
            >
              <ExternalLink size={17} />
              Ver sitio
            </a>
          </div>
        </nav>

        {/* Logout */}
        <div className="px-3 pb-4">
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-sm font-medium text-red-500 hover:bg-red-50 transition-all"
          >
            <LogOut size={17} />
            Cerrar sesion
          </button>
        </div>
      </aside>

      {/* Main */}
      <main className="flex-1 ml-60 min-h-screen">
        {/* Top bar */}
        <header className="bg-white border-b border-gray-100 px-8 py-4 flex items-center justify-between sticky top-0 z-30">
          <div className="flex items-center gap-2 text-sm text-gray-500">
            <span>Admin</span>
            <ChevronRight size={14} />
            <span className="text-black font-semibold capitalize">{tab}</span>
          </div>
          {tab === 'projects' && (
            <button
              onClick={openNew}
              className="flex items-center gap-2 bg-teal-600 hover:bg-teal-500 text-white text-sm font-semibold px-4 py-2 rounded-xl transition-all shadow-sm"
            >
              <Plus size={15} />
              Nuevo proyecto
            </button>
          )}
        </header>

        <div className="p-8">

          {/* ── DASHBOARD ───────────────────────────────── */}
          {tab === 'dashboard' && (
            <div className="flex flex-col gap-8">
              <div>
                <h1 className="text-2xl font-bold text-black mb-1">
                  Bienvenido, {settings?.ownerName ?? 'DesignStudio'}
                </h1>
                <p className="text-gray-500 text-sm">Resumen de tu portafolio</p>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
                {[
                  { label: 'Total proyectos', value: projects.length, icon: FolderKanban, color: 'text-teal-600 bg-teal-50' },
                  { label: 'Proyectos Diseno', value: designCount, icon: Palette, color: 'text-blue-600 bg-blue-50' },
                  { label: 'Proyectos Data', value: dataCount, icon: BarChart2, color: 'text-violet-600 bg-violet-50' },
                  { label: 'Destacados', value: featuredCount, icon: Star, color: 'text-amber-600 bg-amber-50' },
                ].map(({ label, value, icon: Icon, color }) => (
                  <div key={label} className="bg-white border border-gray-100 rounded-2xl p-5 shadow-sm">
                    <div className={`inline-flex items-center justify-center w-10 h-10 rounded-xl ${color} mb-3`}>
                      <Icon size={18} />
                    </div>
                    <p className="text-3xl font-bold text-black">{value}</p>
                    <p className="text-sm text-gray-500 mt-0.5">{label}</p>
                  </div>
                ))}
              </div>

              {/* Quick actions */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm">
                  <h3 className="font-bold text-black mb-4">Acciones rapidas</h3>
                  <div className="flex flex-col gap-2">
                    <button
                      onClick={() => { setTab('projects'); openNew() }}
                      className="flex items-center gap-3 text-sm text-gray-700 hover:text-teal-600 bg-gray-50 hover:bg-teal-50 px-4 py-3 rounded-xl transition-all font-medium border border-transparent hover:border-teal-100"
                    >
                      <Plus size={16} />
                      Agregar nuevo proyecto
                    </button>
                    <button
                      onClick={() => setTab('settings')}
                      className="flex items-center gap-3 text-sm text-gray-700 hover:text-teal-600 bg-gray-50 hover:bg-teal-50 px-4 py-3 rounded-xl transition-all font-medium border border-transparent hover:border-teal-100"
                    >
                      <Settings size={16} />
                      Editar configuracion del sitio
                    </button>
                    <a
                      href="/"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-3 text-sm text-gray-700 hover:text-teal-600 bg-gray-50 hover:bg-teal-50 px-4 py-3 rounded-xl transition-all font-medium border border-transparent hover:border-teal-100"
                    >
                      <Eye size={16} />
                      Ver como cliente
                    </a>
                  </div>
                </div>

                {/* Recent projects */}
                <div className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm">
                  <h3 className="font-bold text-black mb-4">Proyectos recientes</h3>
                  <div className="flex flex-col gap-2">
                    {projects.slice(0, 4).map((p) => (
                      <div key={p.id} className="flex items-center gap-3 text-sm">
                        <div className="w-8 h-8 rounded-lg overflow-hidden bg-gray-100 flex-shrink-0">
                          <img
                            src={p.image}
                            alt={p.title}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="font-medium text-gray-800 truncate">{p.title}</p>
                          <p className="text-xs text-gray-400">{p.category} · {p.year}</p>
                        </div>
                        <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                          p.discipline === 'data' ? 'bg-teal-50 text-teal-700' :
                          p.discipline === 'both' ? 'bg-violet-50 text-violet-700' :
                          'bg-gray-100 text-gray-600'
                        }`}>
                          {p.discipline === 'data' ? 'Data' : p.discipline === 'both' ? 'Ambos' : 'Diseno'}
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* ── PROJECTS ────────────────────────────────── */}
          {tab === 'projects' && (
            <div className="flex flex-col gap-6">
              <div>
                <h1 className="text-2xl font-bold text-black mb-1">Proyectos</h1>
                <p className="text-gray-500 text-sm">{projects.length} proyectos en total</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-5">
                {projects.map((p) => (
                  <div
                    key={p.id}
                    className="bg-white border border-gray-100 rounded-2xl overflow-hidden shadow-sm hover:shadow-md hover:border-teal-100 transition-all group"
                  >
                    {/* Image */}
                    <div className="relative aspect-video overflow-hidden">
                      <img
                        src={p.image}
                        alt={p.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-all" />
                      {p.featured && (
                        <span className="absolute top-2 left-2 flex items-center gap-1 bg-amber-400 text-white text-xs font-bold px-2 py-0.5 rounded-full">
                          <Star size={10} fill="white" />
                          Destacado
                        </span>
                      )}
                      <span className={`absolute top-2 right-2 text-xs font-bold px-2 py-0.5 rounded-full ${
                        p.discipline === 'data' ? 'bg-teal-600 text-white' :
                        p.discipline === 'both' ? 'bg-violet-600 text-white' :
                        'bg-black/60 text-white'
                      }`}>
                        {p.discipline === 'data' ? 'Data' : p.discipline === 'both' ? 'Ambos' : 'Diseno'}
                      </span>
                    </div>

                    {/* Info */}
                    <div className="p-4">
                      <div className="flex items-start justify-between gap-2 mb-1.5">
                        <h3 className="font-bold text-black text-sm leading-snug">{p.title}</h3>
                        <span className="text-xs text-gray-400 flex-shrink-0">{p.year}</span>
                      </div>
                      <p className="text-gray-500 text-xs leading-relaxed mb-3 line-clamp-2">
                        {p.description}
                      </p>
                      <div className="flex flex-wrap gap-1 mb-4">
                        {p.tags.slice(0, 3).map((t) => (
                          <span key={t} className="text-xs bg-teal-50 text-teal-700 border border-teal-100 px-2 py-0.5 rounded-full">
                            {t}
                          </span>
                        ))}
                        {p.tags.length > 3 && (
                          <span className="text-xs text-gray-400 px-1 py-0.5">+{p.tags.length - 3}</span>
                        )}
                      </div>

                      {/* Actions */}
                      <div className="flex gap-2 border-t border-gray-100 pt-3">
                        <button
                          onClick={() => openEdit(p)}
                          className="flex-1 flex items-center justify-center gap-1.5 text-xs font-medium text-gray-600 hover:text-teal-600 bg-gray-50 hover:bg-teal-50 py-2 rounded-lg transition-all border border-transparent hover:border-teal-100"
                        >
                          <Pencil size={12} />
                          Editar
                        </button>
                        <button
                          onClick={() => setDeleteConfirm(p.id)}
                          className="flex-1 flex items-center justify-center gap-1.5 text-xs font-medium text-gray-500 hover:text-red-500 bg-gray-50 hover:bg-red-50 py-2 rounded-lg transition-all border border-transparent hover:border-red-100"
                        >
                          <Trash2 size={12} />
                          Eliminar
                        </button>
                      </div>
                    </div>
                  </div>
                ))}

                {/* Add new card */}
                <button
                  onClick={openNew}
                  className="bg-white border-2 border-dashed border-gray-200 hover:border-teal-300 rounded-2xl flex flex-col items-center justify-center gap-3 py-16 text-gray-400 hover:text-teal-600 transition-all group min-h-[300px]"
                >
                  <div className="w-12 h-12 rounded-xl bg-gray-100 group-hover:bg-teal-50 flex items-center justify-center transition-colors">
                    <Plus size={22} />
                  </div>
                  <span className="text-sm font-medium">Agregar proyecto</span>
                </button>
              </div>
            </div>
          )}

          {/* ── SETTINGS ────────────────────────────────── */}
          {tab === 'settings' && settings && (
            <div className="flex flex-col gap-6 max-w-2xl">
              <div>
                <h1 className="text-2xl font-bold text-black mb-1">Configuracion</h1>
                <p className="text-gray-500 text-sm">Edita el nombre, bio y datos de contacto del sitio</p>
              </div>
              <div className="bg-white border border-gray-100 rounded-2xl p-6 shadow-sm">
                <SettingsForm initial={settings} />
              </div>

              {/* Credentials note */}
              <div className="bg-amber-50 border border-amber-100 rounded-2xl p-5">
                <p className="font-semibold text-amber-800 text-sm mb-2">Credenciales de acceso</p>
                <div className="font-mono text-sm text-amber-700 flex flex-col gap-1">
                  <span>Usuario: <strong>marlon</strong></span>
                  <span>Contrasena: <strong>marlon2024</strong></span>
                </div>
                <p className="text-amber-600 text-xs mt-3 leading-relaxed">
                  Guarda estos datos en un lugar seguro. Accede al panel siempre desde <strong>/admin/login</strong>.
                </p>
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Project form modal */}
      {showForm && (
        <ProjectForm
          initial={editTarget}
          onSave={handleSave}
          onClose={() => { setShowForm(false); setEditTarget(null) }}
        />
      )}

      {/* Delete confirm modal */}
      {deleteConfirm && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 backdrop-blur-sm px-4">
          <div className="bg-white rounded-2xl shadow-2xl p-6 w-full max-w-sm border border-gray-100">
            <div className="flex items-center justify-center w-12 h-12 rounded-full bg-red-50 mx-auto mb-4">
              <Trash2 size={20} className="text-red-500" />
            </div>
            <h3 className="text-center font-bold text-black mb-2">Eliminar proyecto</h3>
            <p className="text-center text-gray-500 text-sm mb-6">
              Esta accion no se puede deshacer. El proyecto sera eliminado permanentemente.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => setDeleteConfirm(null)}
                className="flex-1 py-2.5 text-sm font-medium border border-gray-200 rounded-xl hover:bg-gray-50 transition-all"
              >
                Cancelar
              </button>
              <button
                onClick={() => handleDelete(deleteConfirm)}
                className="flex-1 py-2.5 text-sm font-semibold bg-red-500 hover:bg-red-600 text-white rounded-xl transition-all"
              >
                Si, eliminar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
