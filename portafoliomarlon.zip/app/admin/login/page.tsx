'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Brush, Eye, EyeOff, Lock, User, AlertCircle } from 'lucide-react'
import { login } from '@/lib/store'

export default function AdminLoginPage() {
  const router = useRouter()
  const [username, setUsername] = useState('')
  const [password, setPassword] = useState('')
  const [showPass, setShowPass] = useState(false)
  const [error, setError] = useState('')
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setLoading(true)
    await new Promise((r) => setTimeout(r, 500)) // slight delay for UX
    const ok = login(username.trim(), password)
    if (ok) {
      router.push('/admin')
    } else {
      setError('Usuario o contraseña incorrectos.')
      setLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center px-4">
      {/* Geometric accent */}
      <svg
        className="fixed top-0 right-0 w-96 h-96 text-teal-50 pointer-events-none"
        viewBox="0 0 400 400"
        aria-hidden="true"
      >
        <polygon points="400,0 400,400 0,0" fill="currentColor" />
      </svg>
      <svg
        className="fixed bottom-0 left-0 w-64 h-64 text-teal-50 pointer-events-none"
        viewBox="0 0 256 256"
        aria-hidden="true"
      >
        <polygon points="0,256 256,256 0,0" fill="currentColor" />
      </svg>

      <div className="relative w-full max-w-md">
        {/* Card */}
        <div className="bg-white rounded-3xl shadow-xl border border-gray-100 p-8">
          {/* Logo */}
          <div className="flex flex-col items-center mb-8">
            <div className="flex items-center justify-center w-14 h-14 rounded-2xl bg-teal-500 text-white shadow-lg mb-4">
              <Brush size={24} />
            </div>
            <h1 className="text-2xl font-bold text-black tracking-tight">Marlon Elitim</h1>
            <p className="text-gray-500 text-sm mt-1">Panel de Administración</p>
          </div>

          {/* Credentials hint box */}
          <div className="bg-teal-50 border border-teal-100 rounded-xl p-4 mb-6 text-sm">
            <p className="font-semibold text-teal-700 mb-1.5">Tus credenciales de acceso:</p>
            <div className="flex flex-col gap-1 text-teal-800 font-mono">
              <span>Usuario: <strong>marlon</strong></span>
              <span>Contraseña: <strong>marlon2024</strong></span>
            </div>
            <p className="text-teal-600 text-xs mt-2 leading-relaxed">
              Guarda estos datos en un lugar seguro. Puedes cambiarlos desde el panel.
            </p>
          </div>

          {/* Form */}
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            {/* Username */}
            <div className="flex flex-col gap-1.5">
              <label htmlFor="username" className="text-sm font-semibold text-gray-700">
                Usuario
              </label>
              <div className="relative">
                <User
                  size={16}
                  className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400"
                />
                <input
                  id="username"
                  type="text"
                  autoComplete="username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="admin"
                  required
                  className="w-full pl-10 pr-4 py-3 border border-gray-200 rounded-xl text-sm text-gray-800 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-teal-400 transition-all"
                />
              </div>
            </div>

            {/* Password */}
            <div className="flex flex-col gap-1.5">
              <label htmlFor="password" className="text-sm font-semibold text-gray-700">
                Contraseña
              </label>
              <div className="relative">
                <Lock
                  size={16}
                  className="absolute left-3.5 top-1/2 -translate-y-1/2 text-gray-400"
                />
                <input
                  id="password"
                  type={showPass ? 'text' : 'password'}
                  autoComplete="current-password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••••••••"
                  required
                  className="w-full pl-10 pr-11 py-3 border border-gray-200 rounded-xl text-sm text-gray-800 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-teal-400 transition-all"
                />
                <button
                  type="button"
                  onClick={() => setShowPass(!showPass)}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600 transition-colors"
                  aria-label={showPass ? 'Ocultar contraseña' : 'Mostrar contraseña'}
                >
                  {showPass ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </div>

            {/* Error */}
            {error && (
              <div className="flex items-center gap-2 bg-red-50 border border-red-100 text-red-600 text-sm px-4 py-3 rounded-xl">
                <AlertCircle size={15} />
                {error}
              </div>
            )}

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className="w-full bg-teal-600 hover:bg-teal-500 disabled:opacity-60 text-white font-semibold py-3 rounded-xl transition-all duration-200 shadow-sm mt-1 flex items-center justify-center gap-2"
            >
              {loading ? (
                <span className="w-4 h-4 border-2 border-white/40 border-t-white rounded-full animate-spin" />
              ) : null}
              {loading ? 'Entrando...' : 'Entrar al panel'}
            </button>
          </form>

          {/* Back to site */}
          <div className="mt-6 text-center">
            <a
              href="/"
              className="text-sm text-gray-400 hover:text-teal-600 transition-colors"
            >
              Volver al sitio publico
            </a>
          </div>
        </div>
      </div>
    </div>
  )
}
