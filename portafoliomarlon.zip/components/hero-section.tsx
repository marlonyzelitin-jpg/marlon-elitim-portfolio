'use client'

import { ArrowRight, Sparkles, Star, BarChart2, Palette } from 'lucide-react'

export default function HeroSection() {
  const scrollTo = (id: string) => {
    const el = document.getElementById(id)
    if (el) el.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <section
      id="hero"
      className="relative min-h-screen flex flex-col items-center justify-center overflow-hidden bg-white"
    >
      {/* Geometric triangle background */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none" aria-hidden="true">
        {/* Large teal triangle top-right */}
        <svg className="absolute -top-20 -right-20 w-[500px] h-[500px] opacity-[0.04]" viewBox="0 0 500 500">
          <polygon points="500,0 500,500 0,500" fill="#14B8A6" />
        </svg>
        {/* Medium triangle bottom-left */}
        <svg className="absolute -bottom-10 -left-10 w-[400px] h-[400px] opacity-[0.04]" viewBox="0 0 400 400">
          <polygon points="0,0 400,0 0,400" fill="#14B8A6" />
        </svg>
        {/* Small accent triangles */}
        <svg className="absolute top-1/3 left-8 w-16 h-16 opacity-10" viewBox="0 0 64 64">
          <polygon points="32,0 64,64 0,64" fill="#14B8A6" />
        </svg>
        <svg className="absolute bottom-1/3 right-16 w-12 h-12 opacity-10" viewBox="0 0 48 48">
          <polygon points="24,0 48,48 0,48" fill="#14B8A6" />
        </svg>
        <svg className="absolute top-1/4 right-1/4 w-8 h-8 opacity-10" viewBox="0 0 32 32">
          <polygon points="16,0 32,32 0,32" fill="#14B8A6" />
        </svg>
        {/* Subtle dot grid */}
        <div className="absolute inset-0"
          style={{
            backgroundImage: 'radial-gradient(circle, #d1d5db 1px, transparent 1px)',
            backgroundSize: '40px 40px',
            opacity: 0.4,
          }}
        />
      </div>

      <div className="relative z-10 max-w-5xl mx-auto px-6 flex flex-col items-center text-center gap-8 pt-24">
        {/* Pill badges */}
        <div className="flex flex-wrap items-center justify-center gap-2">
          <div className="inline-flex items-center gap-2 border border-teal-400 text-teal-600 bg-teal-50 px-4 py-1.5 rounded-full text-sm font-semibold tracking-wide shadow-sm">
            <Palette size={13} />
            Award-Winning Designer
          </div>
          <div className="inline-flex items-center gap-2 border border-teal-400 text-teal-600 bg-teal-50 px-4 py-1.5 rounded-full text-sm font-semibold tracking-wide shadow-sm">
            <BarChart2 size={13} />
            Data Analytics Expert
            <Star size={12} className="fill-teal-400 text-teal-400" />
          </div>
        </div>

        {/* Headline */}
        <h1 className="text-5xl md:text-7xl font-bold tracking-tight text-black text-balance leading-[1.08]">
          Design Meets
          <span className="block text-teal-500 relative">
            Data Intelligence
            <span className="absolute -bottom-1 left-0 right-0 h-0.5 bg-teal-200 rounded-full opacity-60" />
          </span>
        </h1>

        {/* Subtext */}
        <p className="text-xl text-gray-500 max-w-2xl leading-relaxed text-pretty">
          From brand identity to data dashboards — I craft visual stories backed by analytical
          precision. Two disciplines, one creative vision.
        </p>

        {/* Dual discipline pills */}
        <div className="flex items-center gap-3 flex-wrap justify-center">
          <span className="flex items-center gap-2 bg-white border border-gray-200 rounded-full px-4 py-2 text-sm font-medium text-gray-700 shadow-sm">
            <span className="w-2 h-2 rounded-full bg-teal-400" />
            Creative Design
          </span>
          <span className="text-gray-300 font-light text-lg">×</span>
          <span className="flex items-center gap-2 bg-white border border-gray-200 rounded-full px-4 py-2 text-sm font-medium text-gray-700 shadow-sm">
            <span className="w-2 h-2 rounded-full bg-teal-600" />
            Data Analysis
          </span>
        </div>

        {/* CTAs */}
        <div className="flex flex-col sm:flex-row items-center gap-4 mt-2">
          <button
            onClick={() => scrollTo('work')}
            className="group flex items-center gap-2 bg-teal-600 hover:bg-teal-500 text-white font-semibold px-7 py-3.5 rounded-full transition-all duration-200 shadow-md hover:shadow-teal-200 hover:shadow-lg"
          >
            View Portfolio
            <ArrowRight size={16} className="group-hover:translate-x-1 transition-transform" />
          </button>
          <button
            onClick={() => scrollTo('contact')}
            className="flex items-center gap-2 border border-gray-300 hover:border-gray-400 text-gray-700 hover:text-black font-semibold px-7 py-3.5 rounded-full transition-all duration-200 bg-white hover:bg-gray-50"
          >
            Get a Quote
          </button>
        </div>

        {/* Trust note */}
        <p className="text-sm text-gray-400 flex items-center gap-3 mt-1">
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-teal-400 inline-block" />
            Free consultation
          </span>
          <span className="w-px h-3 bg-gray-300" />
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-teal-400 inline-block" />
            Fast turnaround
          </span>
          <span className="w-px h-3 bg-gray-300" />
          <span className="flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-teal-400 inline-block" />
            Design + Data
          </span>
        </p>

        {/* Hero image collage — 4 panels showcasing both disciplines */}
        <div className="w-full mt-10 relative">
          <div className="grid grid-cols-3 gap-3 md:gap-4">
            {/* Left large panel — Data dashboard */}
            <div className="col-span-2 relative overflow-hidden rounded-xl group h-64 md:h-80">
              <img
                src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=900&q=80"
                alt="Data analytics dashboard with interactive charts, KPI cards and data visualizations on dark screen"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent" />
              <span className="absolute bottom-3 left-3 text-white text-xs font-semibold bg-black/40 backdrop-blur-sm px-2.5 py-1 rounded-full">
                Data Analytics
              </span>
            </div>
            {/* Right column — two smaller panels */}
            <div className="flex flex-col gap-3 md:gap-4">
              <div className="relative overflow-hidden rounded-xl group flex-1 min-h-[calc(50%-0.375rem)] md:min-h-0">
                <img
                  src="https://images.unsplash.com/photo-1626785774573-4b799315345d?w=400&q=80"
                  alt="UI design wireframes and polished digital mockups on screen"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
                <span className="absolute bottom-2 left-2 text-white text-xs font-semibold bg-black/40 backdrop-blur-sm px-2 py-0.5 rounded-full">
                  UI/UX
                </span>
              </div>
              <div className="relative overflow-hidden rounded-xl group flex-1 min-h-[calc(50%-0.375rem)] md:min-h-0">
                <img
                  src="https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=400&q=80"
                  alt="Statistical data charts and graphs printed on white paper for a research report"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
                <span className="absolute bottom-2 left-2 text-white text-xs font-semibold bg-black/40 backdrop-blur-sm px-2 py-0.5 rounded-full">
                  Reporting
                </span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom wave */}
      <div className="absolute bottom-0 inset-x-0 h-24 bg-gradient-to-t from-gray-50/60 to-transparent pointer-events-none" />
    </section>
  )
}
