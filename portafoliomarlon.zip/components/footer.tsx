import { Brush, Twitter, Instagram, Linkedin, Dribbble, ArrowUpRight } from 'lucide-react'

const designServices = ['Brand Identity', 'UI/UX Design', 'Web Design', 'Illustration']
const dataServices = ['Data Visualization', 'Business Intelligence', 'Data Engineering', 'Predictive Analytics']
const links = ['Work', 'About', 'Services', 'Process', 'Blog', 'Contact']

export default function Footer() {
  const scrollTo = (id: string) => {
    const el = document.getElementById(id.toLowerCase())
    if (el) el.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <footer className="bg-white border-t border-gray-100">
      {/* CTA Banner */}
      <div className="bg-black text-white py-14 px-6 text-center relative overflow-hidden">
        <svg className="absolute left-0 top-0 w-40 h-40 opacity-5" viewBox="0 0 160 160" aria-hidden="true">
          <polygon points="0,0 160,0 0,160" fill="white" />
        </svg>
        <svg className="absolute right-0 bottom-0 w-52 h-52 opacity-5" viewBox="0 0 208 208" aria-hidden="true">
          <polygon points="208,208 208,0 0,208" fill="white" />
        </svg>
        <div className="relative z-10 max-w-2xl mx-auto">
          <p className="text-teal-400 text-sm font-semibold tracking-widest uppercase mb-3">Ready to Start?</p>
          <h3 className="text-3xl md:text-4xl font-bold mb-4 text-balance">
            Have a project in mind?{' '}
            <span className="text-teal-400">Let&apos;s talk.</span>
          </h3>
          <p className="text-gray-400 mb-7">
            Free 30-minute strategy call — design, data, or both. No strings attached.
          </p>
          <button
            onClick={() => {
              const el = document.getElementById('contact')
              if (el) el.scrollIntoView({ behavior: 'smooth' })
            }}
            className="inline-flex items-center gap-2 bg-teal-500 hover:bg-teal-400 text-white font-semibold px-8 py-3.5 rounded-full transition-all duration-200 shadow-lg hover:shadow-teal-500/30"
          >
            Book a Free Call
            <ArrowUpRight size={16} />
          </button>
        </div>
      </div>

      {/* Main footer */}
      <div className="max-w-7xl mx-auto px-6 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10">
          {/* Brand */}
          <div className="md:col-span-1 flex flex-col gap-5">
            <div className="flex items-center gap-2">
              <span className="flex items-center justify-center w-8 h-8 rounded-lg bg-teal-500 text-white shadow-sm">
                <Brush size={16} />
              </span>
              <span className="font-bold text-lg text-black">Marlon Elitim</span>
            </div>
            <p className="text-gray-500 text-sm leading-relaxed">
              Award-winning creative studio specializing in visual design and data analytics — where creativity meets intelligence.
            </p>
            {/* Social icons */}
            <div className="flex gap-3 mt-1">
              {[
                { Icon: Twitter, label: 'Twitter' },
                { Icon: Instagram, label: 'Instagram' },
                { Icon: Linkedin, label: 'LinkedIn' },
                { Icon: Dribbble, label: 'Dribbble' },
              ].map(({ Icon, label }) => (
                <button
                  key={label}
                  aria-label={label}
                  className="w-9 h-9 rounded-full border border-gray-200 flex items-center justify-center text-gray-500 hover:text-teal-600 hover:border-teal-300 hover:bg-teal-50 transition-all"
                >
                  <Icon size={15} />
                </button>
              ))}
            </div>
          </div>

          {/* Design Services */}
          <div className="flex flex-col gap-4">
            <h4 className="font-bold text-black text-sm uppercase tracking-wider">Design</h4>
            <ul className="flex flex-col gap-2.5">
              {designServices.map((s) => (
                <li key={s}>
                  <button className="text-gray-500 hover:text-teal-600 text-sm transition-colors text-left">
                    {s}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Data Services */}
          <div className="flex flex-col gap-4">
            <h4 className="font-bold text-black text-sm uppercase tracking-wider">Data Analytics</h4>
            <ul className="flex flex-col gap-2.5">
              {dataServices.map((s) => (
                <li key={s}>
                  <button className="text-gray-500 hover:text-teal-600 text-sm transition-colors text-left">
                    {s}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Links */}
          <div className="flex flex-col gap-4">
            <h4 className="font-bold text-black text-sm uppercase tracking-wider">Navigation</h4>
            <ul className="flex flex-col gap-2.5">
              {links.map((l) => (
                <li key={l}>
                  <button
                    onClick={() => scrollTo(l)}
                    className="text-gray-500 hover:text-teal-600 text-sm transition-colors text-left"
                  >
                    {l}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Newsletter */}
          <div className="flex flex-col gap-4">
            <h4 className="font-bold text-black text-sm uppercase tracking-wider">Stay Inspired</h4>
            <p className="text-gray-500 text-sm leading-relaxed">
              Get design insights and creative tips delivered to your inbox.
            </p>
            <div className="flex flex-col gap-2 mt-1">
              <input
                type="email"
                placeholder="your@email.com"
                className="border border-gray-200 rounded-xl px-4 py-2.5 text-sm text-gray-800 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-teal-400 transition-all"
              />
              <button className="bg-teal-600 hover:bg-teal-500 text-white font-semibold text-sm px-4 py-2.5 rounded-xl transition-colors w-full">
                Subscribe
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-gray-100 px-6 py-5">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
          <p className="text-gray-400 text-sm">
            © 2024 Marlon Elitim. All rights reserved.
          </p>
          <p className="text-gray-400 text-sm flex items-center gap-1.5">
            <span className="w-1.5 h-1.5 rounded-full bg-teal-400 inline-block" />
            Let&apos;s create something amazing together.
          </p>
          <div className="flex gap-5">
            {['Privacy', 'Terms', 'Cookies'].map((item) => (
              <button key={item} className="text-gray-400 hover:text-gray-600 text-xs transition-colors">
                {item}
              </button>
            ))}
          </div>
        </div>
      </div>
    </footer>
  )
}
