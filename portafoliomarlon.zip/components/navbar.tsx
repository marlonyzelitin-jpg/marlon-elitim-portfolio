'use client'

import { useState, useEffect } from 'react'
import { Brush, Menu, X } from 'lucide-react'

const navLinks = ['Work', 'About', 'Services', 'Contact']

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false)
  const [mobileOpen, setMobileOpen] = useState(false)

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20)
    window.addEventListener('scroll', onScroll)
    return () => window.removeEventListener('scroll', onScroll)
  }, [])

  const scrollTo = (id: string) => {
    setMobileOpen(false)
    const el = document.getElementById(id.toLowerCase())
    if (el) el.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <header
      className={`fixed top-0 inset-x-0 z-50 h-16 transition-all duration-300 ${
        scrolled
          ? 'bg-white/80 backdrop-blur-xl shadow-sm border-b border-gray-100'
          : 'bg-transparent'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 h-full flex items-center justify-between">
        {/* Logo */}
        <button
          onClick={() => scrollTo('hero')}
          className="flex items-center gap-2 group"
          aria-label="Marlon Elitim home"
        >
          <span className="flex items-center justify-center w-8 h-8 rounded-lg bg-teal-500 text-white shadow-md group-hover:bg-teal-600 transition-colors">
            <Brush size={16} />
          </span>
          <span className="font-bold text-lg text-black tracking-tight">
            Marlon Elitim
          </span>
        </button>

        {/* Desktop nav */}
        <nav className="hidden md:flex items-center gap-8">
          {navLinks.map((link) => (
            <button
              key={link}
              onClick={() => scrollTo(link)}
              className="text-sm text-gray-600 hover:text-black transition-colors font-medium tracking-wide"
            >
              {link}
            </button>
          ))}
        </nav>

        {/* CTA */}
        <div className="hidden md:flex items-center gap-3">
          <button
            onClick={() => scrollTo('contact')}
            className="bg-teal-600 hover:bg-teal-500 text-white text-sm font-semibold px-5 py-2 rounded-full transition-all duration-200 shadow-sm hover:shadow-teal-200 hover:shadow-md"
          >
            Hire Me
          </button>
        </div>

        {/* Mobile toggle */}
        <button
          className="md:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
          onClick={() => setMobileOpen(!mobileOpen)}
          aria-label="Toggle menu"
        >
          {mobileOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="md:hidden bg-white/95 backdrop-blur-xl border-b border-gray-100 px-6 py-4 flex flex-col gap-4">
          {navLinks.map((link) => (
            <button
              key={link}
              onClick={() => scrollTo(link)}
              className="text-left text-gray-700 hover:text-black font-medium py-1 transition-colors"
            >
              {link}
            </button>
          ))}
          <button
            onClick={() => scrollTo('contact')}
            className="bg-teal-600 text-white font-semibold px-5 py-2.5 rounded-full w-full mt-2 transition-colors hover:bg-teal-500"
          >
            Hire Me
          </button>
        </div>
      )}
    </header>
  )
}
