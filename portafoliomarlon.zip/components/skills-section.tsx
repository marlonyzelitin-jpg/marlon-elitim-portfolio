import { Pen, Palette, Layout, Megaphone, BarChart2, Database, TrendingUp, BrainCircuit } from 'lucide-react'

const designSkills = [
  {
    icon: Pen,
    title: 'Brand Identity',
    description:
      'Crafting distinctive logos, color systems, and brand guidelines that tell your unique story and resonate with your audience.',
    color: 'bg-teal-50 text-teal-600 border-teal-100',
  },
  {
    icon: Layout,
    title: 'UI/UX Design',
    description:
      'Designing intuitive digital interfaces and seamless user experiences grounded in research and modern design principles.',
    color: 'bg-blue-50 text-blue-600 border-blue-100',
  },
  {
    icon: Megaphone,
    title: 'Creative Strategy',
    description:
      'Developing multi-channel creative strategies and visual languages that make brands stand out in crowded markets.',
    color: 'bg-amber-50 text-amber-600 border-amber-100',
  },
  {
    icon: Palette,
    title: 'Illustration & Art Direction',
    description:
      'Creating bespoke digital illustrations and art-directed visual campaigns with character and unique flair.',
    color: 'bg-pink-50 text-pink-500 border-pink-100',
  },
]

const dataSkills = [
  {
    icon: BarChart2,
    title: 'Data Visualization',
    description:
      'Transforming raw data into stunning, interactive dashboards using Tableau, Power BI, and custom D3.js solutions.',
    color: 'bg-teal-50 text-teal-600 border-teal-100',
  },
  {
    icon: Database,
    title: 'Data Engineering',
    description:
      'Building robust ETL pipelines, data warehouses, and analytics infrastructure with SQL, Python, and dbt.',
    color: 'bg-indigo-50 text-indigo-600 border-indigo-100',
  },
  {
    icon: TrendingUp,
    title: 'Business Intelligence',
    description:
      'Delivering actionable insights through KPI frameworks, cohort analysis, and executive reporting that drives decisions.',
    color: 'bg-emerald-50 text-emerald-600 border-emerald-100',
  },
  {
    icon: BrainCircuit,
    title: 'Predictive Analytics',
    description:
      'Applying machine learning models to forecast trends, detect anomalies, and surface hidden patterns in complex datasets.',
    color: 'bg-violet-50 text-violet-600 border-violet-100',
  },
]

export default function SkillsSection() {
  return (
    <section id="services" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="text-center mb-16 max-w-2xl mx-auto">
          <span className="text-teal-500 text-sm font-semibold tracking-widest uppercase mb-3 block">
            Services
          </span>
          <h2 className="text-4xl md:text-5xl font-bold text-black tracking-tight mb-5 text-balance">
            What I Do
          </h2>
          <p className="text-gray-500 text-lg leading-relaxed">
            Two powerful disciplines under one roof — creative design that captivates and data
            analytics that informs.
          </p>
        </div>

        {/* Design discipline */}
        <div className="mb-12">
          <div className="flex items-center gap-3 mb-7">
            <span className="w-2 h-2 rounded-full bg-teal-500" />
            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest">
              Creative Design
            </h3>
            <div className="flex-1 h-px bg-gray-100" />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {designSkills.map(({ icon: Icon, title, description, color }) => (
              <div
                key={title}
                className="group relative bg-white border border-gray-100 hover:border-teal-200/70 rounded-2xl p-6 shadow-sm hover:shadow-lg hover:shadow-teal-50 transition-all duration-300 overflow-hidden cursor-default"
              >
                <svg
                  className="absolute -bottom-5 -right-5 w-24 h-24 opacity-[0.03] group-hover:opacity-[0.06] transition-opacity text-teal-500"
                  viewBox="0 0 96 96"
                  aria-hidden="true"
                >
                  <polygon points="48,0 96,96 0,96" fill="currentColor" />
                </svg>
                <div
                  className={`inline-flex items-center justify-center w-11 h-11 rounded-xl border ${color} mb-4 shadow-sm group-hover:scale-110 transition-transform duration-300`}
                >
                  <Icon size={20} />
                </div>
                <h4 className="font-bold text-black text-base mb-2 group-hover:text-teal-600 transition-colors">
                  {title}
                </h4>
                <p className="text-gray-500 text-sm leading-relaxed">{description}</p>
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-teal-500 to-teal-300 scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left rounded-full" />
              </div>
            ))}
          </div>
        </div>

        {/* Data discipline */}
        <div className="mb-16">
          <div className="flex items-center gap-3 mb-7">
            <span className="w-2 h-2 rounded-full bg-teal-600" />
            <h3 className="text-xs font-bold text-gray-500 uppercase tracking-widest">
              Data Analytics
            </h3>
            <div className="flex-1 h-px bg-gray-100" />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {dataSkills.map(({ icon: Icon, title, description, color }) => (
              <div
                key={title}
                className="group relative bg-white border border-gray-100 hover:border-teal-200/70 rounded-2xl p-6 shadow-sm hover:shadow-lg hover:shadow-teal-50 transition-all duration-300 overflow-hidden cursor-default"
              >
                <svg
                  className="absolute -bottom-5 -right-5 w-24 h-24 opacity-[0.03] group-hover:opacity-[0.06] transition-opacity text-teal-600"
                  viewBox="0 0 96 96"
                  aria-hidden="true"
                >
                  <polygon points="48,0 96,96 0,96" fill="currentColor" />
                </svg>
                <div
                  className={`inline-flex items-center justify-center w-11 h-11 rounded-xl border ${color} mb-4 shadow-sm group-hover:scale-110 transition-transform duration-300`}
                >
                  <Icon size={20} />
                </div>
                <h4 className="font-bold text-black text-base mb-2 group-hover:text-teal-600 transition-colors">
                  {title}
                </h4>
                <p className="text-gray-500 text-sm leading-relaxed">{description}</p>
                <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gradient-to-r from-teal-600 to-teal-400 scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left rounded-full" />
              </div>
            ))}
          </div>
        </div>

        {/* Process strip */}
        <div className="bg-teal-600 rounded-3xl p-10 text-white relative overflow-hidden">
          <svg className="absolute right-0 top-0 h-full opacity-10" viewBox="0 0 300 200" aria-hidden="true">
            <polygon points="300,0 300,200 100,200" fill="white" />
            <polygon points="200,0 300,0 300,100" fill="white" opacity="0.5" />
          </svg>
          <div className="relative z-10">
            <p className="text-teal-200 text-xs font-bold uppercase tracking-widest mb-6">My Process</p>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
              {['Discover', 'Design & Analyze', 'Refine', 'Deliver'].map((step, i) => (
                <div key={step} className="flex flex-col gap-3">
                  <span className="text-teal-200 text-sm font-semibold">0{i + 1}</span>
                  <h4 className="font-bold text-xl">{step}</h4>
                  <p className="text-teal-100 text-sm leading-relaxed">
                    {[
                      'Deep dive into your goals, data sources, audience, and competitive landscape.',
                      'Parallel creative exploration and data modelling to build both visuals and insight.',
                      'Collaborative feedback loops to perfect every detail — pixel and metric alike.',
                      'Final design assets and data deliverables ready for launch and decision-making.',
                    ][i]}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
