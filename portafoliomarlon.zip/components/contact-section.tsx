'use client'

import { useState } from 'react'
import { Send, Mail, MapPin, Clock, CheckCircle2 } from 'lucide-react'

export default function ContactSection() {
  const [form, setForm] = useState({ name: '', email: '', project: '', message: '' })
  const [submitted, setSubmitted] = useState(false)
  const [loading, setLoading] = useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setTimeout(() => {
      setLoading(false)
      setSubmitted(true)
    }, 1400)
  }

  return (
    <section id="contact" className="py-24 bg-gray-50 relative overflow-hidden">
      {/* Geo bg */}
      <svg className="absolute -top-10 -right-10 w-64 h-64 opacity-[0.04] text-teal-500" viewBox="0 0 256 256" aria-hidden="true">
        <polygon points="256,0 256,256 0,256" fill="currentColor" />
      </svg>

      <div className="max-w-7xl mx-auto px-6 relative z-10">
        {/* Header */}
        <div className="text-center mb-16">
          <span className="text-teal-500 text-sm font-semibold tracking-widest uppercase mb-3 block">
            Get in Touch
          </span>
          <h2 className="text-4xl md:text-5xl font-bold text-black tracking-tight mb-4 text-balance">
            Let&apos;s Build Something
            <span className="text-teal-500"> Amazing</span>
          </h2>
          <p className="text-gray-500 text-lg max-w-xl mx-auto leading-relaxed">
            Ready to start a project? Drop me a message and I&apos;ll get back to you within 24 hours.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-10 items-start">
          {/* Info column */}
          <div className="lg:col-span-2 flex flex-col gap-8">
            <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-7">
              <h3 className="font-bold text-black text-lg mb-6">Contact Info</h3>
              <div className="flex flex-col gap-5">
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-teal-50 border border-teal-100 flex items-center justify-center shrink-0">
                    <Mail size={18} className="text-teal-600" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-400 font-medium mb-0.5 uppercase tracking-wide">Email</p>
                    <p className="text-gray-700 font-semibold text-sm">hello@designstudio.co</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-teal-50 border border-teal-100 flex items-center justify-center shrink-0">
                    <MapPin size={18} className="text-teal-600" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-400 font-medium mb-0.5 uppercase tracking-wide">Location</p>
                    <p className="text-gray-700 font-semibold text-sm">San Francisco, CA</p>
                    <p className="text-gray-400 text-xs">Available worldwide remotely</p>
                  </div>
                </div>
                <div className="flex items-start gap-4">
                  <div className="w-10 h-10 rounded-xl bg-teal-50 border border-teal-100 flex items-center justify-center shrink-0">
                    <Clock size={18} className="text-teal-600" />
                  </div>
                  <div>
                    <p className="text-xs text-gray-400 font-medium mb-0.5 uppercase tracking-wide">Response Time</p>
                    <p className="text-gray-700 font-semibold text-sm">Within 24 hours</p>
                    <p className="text-gray-400 text-xs">Mon – Fri, 9am – 6pm PST</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Availability badge */}
            <div className="bg-teal-600 rounded-2xl p-7 text-white relative overflow-hidden">
              <svg className="absolute right-0 bottom-0 w-32 h-32 opacity-10" viewBox="0 0 128 128" aria-hidden="true">
                <polygon points="128,128 128,0 0,128" fill="white" />
              </svg>
              <div className="w-3 h-3 rounded-full bg-green-300 animate-pulse mb-4" />
              <p className="font-bold text-xl mb-2">Available for Projects</p>
              <p className="text-teal-100 text-sm leading-relaxed mb-3">
                Currently accepting new clients for Q2 2024. Limited spots for both design and data analytics engagements.
              </p>
              <div className="flex flex-wrap gap-2">
                <span className="text-xs bg-white/10 text-teal-100 border border-teal-400/30 px-2.5 py-1 rounded-full font-medium">
                  Creative Design
                </span>
                <span className="text-xs bg-white/10 text-teal-100 border border-teal-400/30 px-2.5 py-1 rounded-full font-medium">
                  Data Analytics
                </span>
              </div>
            </div>
          </div>

          {/* Form */}
          <div className="lg:col-span-3 bg-white rounded-2xl border border-gray-100 shadow-sm p-8">
            {submitted ? (
              <div className="flex flex-col items-center justify-center py-16 text-center gap-4">
                <div className="w-16 h-16 rounded-full bg-teal-50 flex items-center justify-center">
                  <CheckCircle2 size={32} className="text-teal-500" />
                </div>
                <h3 className="font-bold text-black text-2xl">Message Sent!</h3>
                <p className="text-gray-500 max-w-sm">
                  Thanks for reaching out. I&apos;ll review your project and get back to you within 24 hours.
                </p>
                <button
                  onClick={() => { setSubmitted(false); setForm({ name: '', email: '', project: '', message: '' }) }}
                  className="mt-4 text-teal-600 font-semibold text-sm hover:underline"
                >
                  Send another message
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="flex flex-col gap-5">
                <h3 className="font-bold text-black text-xl mb-1">Start a Project</h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide" htmlFor="name">
                      Name *
                    </label>
                    <input
                      id="name"
                      type="text"
                      required
                      value={form.name}
                      onChange={(e) => setForm({ ...form, name: e.target.value })}
                      placeholder="Your full name"
                      className="border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-teal-400 transition-all"
                    />
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide" htmlFor="email">
                      Email *
                    </label>
                    <input
                      id="email"
                      type="email"
                      required
                      value={form.email}
                      onChange={(e) => setForm({ ...form, email: e.target.value })}
                      placeholder="you@company.com"
                      className="border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-teal-400 transition-all"
                    />
                  </div>
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide" htmlFor="project">
                    Project Type
                  </label>
                  <select
                    id="project"
                    value={form.project}
                    onChange={(e) => setForm({ ...form, project: e.target.value })}
                    className="border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-teal-400 transition-all bg-white"
                  >
                    <option value="">Select a service...</option>
                    <optgroup label="Creative Design">
                      <option value="brand">Brand Identity</option>
                      <option value="uiux">UI/UX Design</option>
                      <option value="web">Web Design</option>
                      <option value="illustration">Illustration</option>
                    </optgroup>
                    <optgroup label="Data Analytics">
                      <option value="dataviz">Data Visualization / Dashboard</option>
                      <option value="dataeng">Data Engineering / ETL</option>
                      <option value="bi">Business Intelligence</option>
                      <option value="ml">Predictive Analytics / ML</option>
                    </optgroup>
                    <option value="both">Design + Data (Combined Project)</option>
                    <option value="other">Other</option>
                  </select>
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="text-xs font-semibold text-gray-500 uppercase tracking-wide" htmlFor="message">
                    Message *
                  </label>
                  <textarea
                    id="message"
                    required
                    rows={5}
                    value={form.message}
                    onChange={(e) => setForm({ ...form, message: e.target.value })}
                    placeholder="Tell me about your project, goals, timeline..."
                    className="border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-800 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-teal-400 focus:border-teal-400 transition-all resize-none"
                  />
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className="flex items-center justify-center gap-2 bg-teal-600 hover:bg-teal-500 disabled:bg-teal-400 text-white font-semibold px-8 py-3.5 rounded-xl transition-all duration-200 shadow-sm hover:shadow-teal-200 hover:shadow-md mt-2"
                >
                  {loading ? (
                    <>
                      <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Sending...
                    </>
                  ) : (
                    <>
                      <Send size={16} />
                      Send Message
                    </>
                  )}
                </button>
                <p className="text-center text-xs text-gray-400">
                  Free consultation • No commitment required
                </p>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  )
}
