'use client'

import { useState, useEffect } from 'react'
import { ArrowUpRight } from 'lucide-react'
import { getProjects, type Project } from '@/lib/store'

const FILTERS = ['All', 'Branding', 'UI/UX', 'Web Design', 'Data Analytics', 'Data Science']

export default function ProjectsSection() {
  const [projects, setProjects] = useState<Project[]>([])
  const [active, setActive] = useState('All')

  useEffect(() => {
    // Sort: featured first, then by order
    const all = getProjects().sort((a, b) => {
      if (a.featured && !b.featured) return -1
      if (!a.featured && b.featured) return 1
      return a.order - b.order
    })
    setProjects(all)
  }, [])

  const filtered = active === 'All' ? projects : projects.filter((p) => p.category === active)

  return (
    <section id="work" className="py-24 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        {/* Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <span className="text-teal-500 text-sm font-semibold tracking-widest uppercase mb-3 block">
              Selected Work
            </span>
            <h2 className="text-4xl md:text-5xl font-bold text-black tracking-tight text-balance">
              Projects That
              <br />
              <span className="text-teal-500">Define Excellence</span>
            </h2>
          </div>
          <p className="text-gray-500 max-w-xs leading-relaxed text-pretty">
            A curated mix of creative design and data analytics work — two disciplines, one studio.
          </p>
        </div>

        {/* Filter pills */}
        <div className="flex flex-wrap gap-2 mb-10">
          {FILTERS.map((f) => (
            <button
              key={f}
              onClick={() => setActive(f)}
              className={`px-4 py-1.5 rounded-full text-sm font-medium transition-all duration-200 ${
                active === f
                  ? 'bg-teal-600 text-white shadow-sm'
                  : 'bg-gray-100 text-gray-600 hover:bg-gray-200 hover:text-black'
              }`}
            >
              {f}
            </button>
          ))}
        </div>

        {/* Projects grid */}
        {filtered.length === 0 ? (
          <div className="text-center py-20 text-gray-400">
            <p className="text-lg font-medium">No hay proyectos en esta categoria.</p>
            <p className="text-sm mt-1">Agrega proyectos desde el panel de administracion.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filtered.map((project, i) => (
              <article
                key={project.id}
                className="group relative bg-white rounded-2xl overflow-hidden border border-gray-100 hover:border-teal-200/60 shadow-sm hover:shadow-xl hover:shadow-teal-50 transition-all duration-300 cursor-pointer"
                style={{ animationDelay: `${i * 60}ms` }}
              >
                {/* Image */}
                <div className="relative overflow-hidden aspect-[4/3]">
                  <img
                    src={project.image}
                    alt={project.title}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                  />
                  <div className="absolute inset-0 bg-teal-600/0 group-hover:bg-teal-600/20 transition-all duration-300" />

                  {/* View case study button */}
                  <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    <span className="flex items-center gap-2 bg-white text-teal-700 font-semibold text-sm px-5 py-2.5 rounded-full shadow-lg">
                      View Case Study
                      <ArrowUpRight size={14} />
                    </span>
                  </div>

                  {/* Badges */}
                  <span className="absolute top-3 left-3 bg-white/90 backdrop-blur-sm text-gray-700 text-xs font-semibold px-2.5 py-1 rounded-full">
                    {project.category}
                  </span>
                  <span className="absolute top-3 right-3 text-white/80 text-xs bg-black/30 backdrop-blur-sm px-2 py-0.5 rounded-full">
                    {project.year}
                  </span>
                  <span
                    className={`absolute bottom-3 right-3 text-xs font-bold px-2.5 py-1 rounded-full backdrop-blur-sm ${
                      project.discipline === 'data'
                        ? 'bg-teal-600/90 text-white'
                        : project.discipline === 'both'
                        ? 'bg-violet-600/90 text-white'
                        : 'bg-black/60 text-white'
                    }`}
                  >
                    {project.discipline === 'data' ? 'Data' : project.discipline === 'both' ? 'Design + Data' : 'Design'}
                  </span>
                </div>

                {/* Content */}
                <div className="p-5">
                  <h3 className="font-bold text-black text-lg mb-1.5 group-hover:text-teal-600 transition-colors">
                    {project.title}
                  </h3>
                  <p className="text-gray-500 text-sm leading-relaxed mb-4">{project.description}</p>
                  <div className="flex flex-wrap gap-1.5">
                    {project.tags.map((tag) => (
                      <span
                        key={tag}
                        className="text-xs text-teal-700 bg-teal-50 border border-teal-100 px-2.5 py-0.5 rounded-full font-medium"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>
              </article>
            ))}
          </div>
        )}

        {/* Load more */}
        <div className="flex justify-center mt-12">
          <button className="flex items-center gap-2 border border-gray-200 hover:border-teal-300 text-gray-700 hover:text-teal-600 font-semibold px-8 py-3 rounded-full transition-all duration-200 bg-white hover:bg-teal-50">
            View All Projects
            <ArrowUpRight size={16} />
          </button>
        </div>
      </div>
    </section>
  )
}
