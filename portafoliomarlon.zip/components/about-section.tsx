import { Award, Users, Clock, BarChart2, Database, Palette } from 'lucide-react'

const stats = [
  { icon: Award, value: '8+', label: 'Years Experience' },
  { icon: Users, value: '120+', label: 'Happy Clients' },
  { icon: Clock, value: '300+', label: 'Projects Delivered' },
  { icon: BarChart2, value: '98%', label: 'Client Satisfaction' },
]

const designTags = ['Brand Identity', 'UI/UX Design', 'Art Direction', 'Typography', 'Illustration']
const dataTags = ['Python', 'SQL', 'Power BI', 'Tableau', 'Machine Learning', 'dbt']

export default function AboutSection() {
  return (
    <section id="about" className="py-24 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Image side */}
          <div className="relative">
            <div className="relative rounded-2xl overflow-hidden aspect-[4/5] shadow-2xl">
              <img
                src="https://images.unsplash.com/photo-1542038784456-1ea8e935640e?w=800&q=80"
                alt="Creative professional working at a desk surrounded by design materials and data reports"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-br from-teal-600/10 to-transparent" />
            </div>

            {/* Floating dual-discipline card */}
            <div className="absolute -bottom-6 -right-6 bg-white rounded-2xl shadow-xl p-5 border border-gray-100 flex flex-col gap-2 min-w-[140px]">
              <div className="flex items-center gap-2">
                <Palette size={14} className="text-teal-500" />
                <p className="text-xs text-gray-500 font-medium">Design</p>
              </div>
              <div className="flex items-center gap-2">
                <Database size={14} className="text-teal-600" />
                <p className="text-xs text-gray-500 font-medium">Data Analytics</p>
              </div>
              <p className="text-2xl font-bold text-teal-600 mt-1">120+</p>
              <p className="text-xs text-gray-400 -mt-1">Happy Clients</p>
            </div>

            {/* Teal accent block */}
            <div className="absolute -top-4 -left-4 w-20 h-20 bg-teal-500 rounded-2xl opacity-20 -z-10" />
            <svg className="absolute -bottom-2 -left-8 w-32 h-32 text-teal-100 opacity-40 -z-10" viewBox="0 0 128 128" aria-hidden="true">
              <polygon points="64,0 128,128 0,128" fill="currentColor" />
            </svg>
          </div>

          {/* Text side */}
          <div className="flex flex-col gap-7">
            <span className="text-teal-500 text-sm font-semibold tracking-widest uppercase">
              About Me
            </span>
            <h2 className="text-4xl md:text-5xl font-bold text-black tracking-tight leading-[1.1] text-balance">
              Where Creativity
              <span className="block text-teal-500">Meets Data</span>
            </h2>
            <p className="text-gray-500 text-lg leading-relaxed">
              I&apos;m a creative designer and data analyst with over 8 years of experience helping
              brands find their visual voice and make smarter decisions. My work sits at the rare
              intersection of artistry and analytical rigor.
            </p>
            <p className="text-gray-500 leading-relaxed">
              From brand identities for funded startups to predictive models for Fortune 500
              companies — every project starts with a deep understanding of your goals and ends
              with work that drives real, measurable results.
            </p>

            {/* Dual skill tags */}
            <div className="flex flex-col gap-3 mt-1">
              <div>
                <p className="text-xs text-gray-400 font-semibold uppercase tracking-widest mb-2">
                  Creative Design
                </p>
                <div className="flex flex-wrap gap-2">
                  {designTags.map((skill) => (
                    <span
                      key={skill}
                      className="bg-white border border-gray-200 text-gray-700 text-sm font-medium px-3.5 py-1.5 rounded-full shadow-sm"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
              <div>
                <p className="text-xs text-gray-400 font-semibold uppercase tracking-widest mb-2">
                  Data Analytics
                </p>
                <div className="flex flex-wrap gap-2">
                  {dataTags.map((skill) => (
                    <span
                      key={skill}
                      className="bg-teal-50 border border-teal-100 text-teal-700 text-sm font-medium px-3.5 py-1.5 rounded-full shadow-sm"
                    >
                      {skill}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Stats row */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-4">
              {stats.map(({ icon: Icon, value, label }) => (
                <div key={label} className="text-center bg-white rounded-xl p-4 border border-gray-100 shadow-sm">
                  <Icon size={20} className="text-teal-500 mx-auto mb-2" />
                  <p className="text-2xl font-bold text-black">{value}</p>
                  <p className="text-xs text-gray-500 mt-0.5">{label}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
