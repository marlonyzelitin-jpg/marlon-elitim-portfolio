'use client'

import { useState } from 'react'
import { ChevronLeft, ChevronRight, Star } from 'lucide-react'

const testimonials = [
  {
    id: 1,
    quote:
      'Working with Marlon transformed our brand completely. The attention to detail and creative vision exceeded every expectation. Our conversion rate jumped 40% after the rebrand.',
    name: 'Sarah Chen',
    role: 'CEO, NovaTech',
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=120&q=80',
    avatarAlt: 'Portrait of Sarah Chen, CEO of NovaTech, smiling professionally',
    rating: 5,
    discipline: 'Design',
  },
  {
    id: 2,
    quote:
      'The data analytics work was transformative. The churn prediction model alone saved us over $800K in the first quarter, and the dashboards finally gave our leadership team clarity on what was driving growth.',
    name: 'Marcus Reid',
    role: 'Head of Data, Pulse Health',
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=120&q=80',
    avatarAlt: 'Portrait of Marcus Reid, head of data at Pulse Health, wearing casual attire',
    rating: 5,
    discipline: 'Data Analytics',
  },
  {
    id: 3,
    quote:
      'Rare to find someone who can both design a beautiful dashboard AND build the data pipeline behind it. The supply chain analytics project cut our reporting time by 70% and the visuals are stunning.',
    name: 'Priya Sharma',
    role: 'Operations Director, Verdant Foods',
    avatar: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?w=120&q=80',
    avatarAlt: 'Portrait of Priya Sharma, operations director at Verdant Foods',
    rating: 5,
    discipline: 'Design + Data',
  },
]

export default function TestimonialsSection() {
  const [current, setCurrent] = useState(0)

  const prev = () => setCurrent((c) => (c === 0 ? testimonials.length - 1 : c - 1))
  const next = () => setCurrent((c) => (c === testimonials.length - 1 ? 0 : c + 1))

  const t = testimonials[current]

  return (
    <section className="py-24 bg-gray-50 relative overflow-hidden">
      {/* Geometric accents */}
      <svg className="absolute left-0 top-0 w-48 h-48 opacity-5 text-teal-500" viewBox="0 0 192 192" aria-hidden="true">
        <polygon points="0,0 192,0 0,192" fill="currentColor" />
      </svg>
      <svg className="absolute right-0 bottom-0 w-64 h-64 opacity-5 text-teal-500" viewBox="0 0 256 256" aria-hidden="true">
        <polygon points="256,256 256,0 0,256" fill="currentColor" />
      </svg>

      <div className="max-w-4xl mx-auto px-6 relative z-10">
        <div className="text-center mb-14">
          <span className="text-teal-500 text-sm font-semibold tracking-widest uppercase mb-3 block">
            Testimonials
          </span>
          <h2 className="text-4xl md:text-5xl font-bold text-black tracking-tight text-balance">
            What Clients Say
          </h2>
        </div>

        {/* Card */}
        <div className="bg-white rounded-3xl border border-gray-100 shadow-xl p-10 md:p-14 text-center relative">
          {/* Discipline + Stars */}
          <div className="flex flex-col items-center gap-3 mb-6">
            <span className="inline-flex items-center gap-1.5 text-xs font-semibold text-teal-700 bg-teal-50 border border-teal-100 px-3 py-1 rounded-full">
              {t.discipline}
            </span>
            <div className="flex gap-1">
              {Array.from({ length: t.rating }).map((_, i) => (
                <Star key={i} size={18} className="fill-teal-400 text-teal-400" />
              ))}
            </div>
          </div>

          {/* Quote */}
          <blockquote className="text-xl md:text-2xl text-gray-700 leading-relaxed font-medium text-balance mb-8">
            &ldquo;{t.quote}&rdquo;
          </blockquote>

          {/* Author */}
          <div className="flex items-center justify-center gap-4">
            <img
              src={t.avatar}
              alt={t.avatarAlt}
              className="w-12 h-12 rounded-full object-cover ring-2 ring-teal-100"
            />
            <div className="text-left">
              <p className="font-bold text-black text-sm">{t.name}</p>
              <p className="text-gray-500 text-xs">{t.role}</p>
            </div>
          </div>

          {/* Quote mark decoration */}
          <span className="absolute top-8 left-10 text-8xl text-teal-100 font-serif leading-none select-none" aria-hidden="true">
            &ldquo;
          </span>
        </div>

        {/* Navigation */}
        <div className="flex items-center justify-center gap-4 mt-8">
          <button
            onClick={prev}
            className="w-10 h-10 rounded-full border border-gray-200 flex items-center justify-center hover:border-teal-300 hover:text-teal-600 transition-colors bg-white"
            aria-label="Previous testimonial"
          >
            <ChevronLeft size={18} />
          </button>
          {/* Dots */}
          <div className="flex gap-2">
            {testimonials.map((_, i) => (
              <button
                key={i}
                onClick={() => setCurrent(i)}
                className={`rounded-full transition-all duration-300 ${
                  i === current ? 'w-6 h-2.5 bg-teal-500' : 'w-2.5 h-2.5 bg-gray-200'
                }`}
                aria-label={`Go to testimonial ${i + 1}`}
              />
            ))}
          </div>
          <button
            onClick={next}
            className="w-10 h-10 rounded-full border border-gray-200 flex items-center justify-center hover:border-teal-300 hover:text-teal-600 transition-colors bg-white"
            aria-label="Next testimonial"
          >
            <ChevronRight size={18} />
          </button>
        </div>
      </div>
    </section>
  )
}
