'use client'

import { useState } from 'react'
import { Check } from 'lucide-react'
import { type SiteSettings, saveSettings } from '@/lib/store'

interface Props {
  initial: SiteSettings
}

export default function SettingsForm({ initial }: Props) {
  const [form, setForm] = useState<SiteSettings>(initial)
  const [saved, setSaved] = useState(false)

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault()
    saveSettings(form)
    setSaved(true)
    setTimeout(() => setSaved(false), 2500)
  }

  const field = (
    label: string,
    key: keyof SiteSettings,
    type: string = 'text',
    placeholder?: string
  ) => (
    <div className="flex flex-col gap-1.5">
      <label className="text-sm font-semibold text-gray-700">{label}</label>
      <input
        type={type}
        value={form[key] as string}
        onChange={(e) => setForm({ ...form, [key]: e.target.value })}
        placeholder={placeholder}
        className="border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-teal-400 transition-all"
      />
    </div>
  )

  return (
    <form onSubmit={handleSave} className="flex flex-col gap-5">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {field('Tu nombre', 'ownerName', 'text', 'Marlon Elitim')}
        {field('Tagline principal', 'tagline', 'text', 'Design Meets Data Intelligence')}
        {field('Email de contacto', 'email', 'email', 'contacto@marlonelitim.com')}
        {field('Telefono', 'phone', 'text', '+1 (555) 000-0000')}
        {field('Ubicacion', 'location', 'text', 'Remote — Worldwide')}
      </div>

      {/* Bio */}
      <div className="flex flex-col gap-1.5">
        <label className="text-sm font-semibold text-gray-700">Bio / Descripcion</label>
        <textarea
          value={form.bio}
          onChange={(e) => setForm({ ...form, bio: e.target.value })}
          rows={3}
          className="border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-teal-400 transition-all resize-none"
        />
      </div>

      {/* Available toggle */}
      <label className="flex items-center gap-3 cursor-pointer select-none">
        <div
          onClick={() => setForm({ ...form, availableForWork: !form.availableForWork })}
          className={`relative w-11 h-6 rounded-full transition-colors duration-200 ${form.availableForWork ? 'bg-teal-500' : 'bg-gray-200'}`}
          role="switch"
          aria-checked={form.availableForWork}
        >
          <span
            className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform duration-200 ${form.availableForWork ? 'translate-x-5' : 'translate-x-0'}`}
          />
        </div>
        <div>
          <p className="text-sm font-semibold text-gray-700">Disponible para proyectos</p>
          <p className="text-xs text-gray-400">Muestra el badge verde en el sitio</p>
        </div>
      </label>

      <div className="flex justify-end pt-2 border-t border-gray-100">
        <button
          type="submit"
          className={`flex items-center gap-2 px-6 py-2.5 text-sm font-semibold rounded-xl transition-all shadow-sm ${
            saved
              ? 'bg-green-500 text-white'
              : 'bg-teal-600 hover:bg-teal-500 text-white'
          }`}
        >
          {saved && <Check size={15} />}
          {saved ? 'Guardado' : 'Guardar configuracion'}
        </button>
      </div>
    </form>
  )
}
