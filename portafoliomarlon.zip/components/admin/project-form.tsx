'use client'

import { useState } from 'react'
import { X, Plus, Tag } from 'lucide-react'
import { type Project } from '@/lib/store'

interface Props {
  initial?: Project | null
  onSave: (data: Omit<Project, 'id' | 'order'>) => void
  onClose: () => void
}

const CATEGORIES = ['Branding', 'UI/UX', 'Web Design', 'Data Analytics', 'Data Science', 'Illustration', 'Creative Strategy', 'Other']

const BLANK: Omit<Project, 'id' | 'order'> = {
  title: '',
  description: '',
  category: 'Branding',
  discipline: 'design',
  image: '',
  tags: [],
  year: String(new Date().getFullYear()),
  featured: false,
}

export default function ProjectForm({ initial, onSave, onClose }: Props) {
  const [form, setForm] = useState<Omit<Project, 'id' | 'order'>>(
    initial
      ? { title: initial.title, description: initial.description, category: initial.category, discipline: initial.discipline, image: initial.image, tags: initial.tags, year: initial.year, featured: initial.featured }
      : BLANK
  )
  const [tagInput, setTagInput] = useState('')
  const [errors, setErrors] = useState<Record<string, string>>({})

  const validate = () => {
    const e: Record<string, string> = {}
    if (!form.title.trim()) e.title = 'El titulo es obligatorio'
    if (!form.description.trim()) e.description = 'La descripcion es obligatoria'
    if (!form.image.trim()) e.image = 'La URL de la imagen es obligatoria'
    setErrors(e)
    return Object.keys(e).length === 0
  }

  const addTag = () => {
    const t = tagInput.trim()
    if (t && !form.tags.includes(t)) {
      setForm({ ...form, tags: [...form.tags, t] })
    }
    setTagInput('')
  }

  const removeTag = (tag: string) => {
    setForm({ ...form, tags: form.tags.filter((t) => t !== tag) })
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (validate()) onSave(form)
  }

  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center bg-black/40 backdrop-blur-sm overflow-y-auto py-8 px-4">
      <div className="bg-white rounded-2xl shadow-2xl w-full max-w-2xl border border-gray-100">
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-gray-100">
          <h2 className="font-bold text-lg text-black">
            {initial ? 'Editar Proyecto' : 'Nuevo Proyecto'}
          </h2>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg hover:bg-gray-100 transition-colors text-gray-500 hover:text-black"
            aria-label="Cerrar"
          >
            <X size={18} />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 flex flex-col gap-5">
          {/* Title */}
          <div className="flex flex-col gap-1.5">
            <label className="text-sm font-semibold text-gray-700">Titulo *</label>
            <input
              type="text"
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              placeholder="Ej: Nova Brand Identity"
              className={`border rounded-xl px-4 py-3 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-teal-400 transition-all ${errors.title ? 'border-red-300 bg-red-50' : 'border-gray-200'}`}
            />
            {errors.title && <p className="text-red-500 text-xs">{errors.title}</p>}
          </div>

          {/* Description */}
          <div className="flex flex-col gap-1.5">
            <label className="text-sm font-semibold text-gray-700">Descripcion *</label>
            <textarea
              value={form.description}
              onChange={(e) => setForm({ ...form, description: e.target.value })}
              placeholder="Breve descripcion del proyecto..."
              rows={3}
              className={`border rounded-xl px-4 py-3 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-teal-400 transition-all resize-none ${errors.description ? 'border-red-300 bg-red-50' : 'border-gray-200'}`}
            />
            {errors.description && <p className="text-red-500 text-xs">{errors.description}</p>}
          </div>

          {/* Image URL */}
          <div className="flex flex-col gap-1.5">
            <label className="text-sm font-semibold text-gray-700">URL de imagen *</label>
            <input
              type="url"
              value={form.image}
              onChange={(e) => setForm({ ...form, image: e.target.value })}
              placeholder="https://images.unsplash.com/..."
              className={`border rounded-xl px-4 py-3 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-teal-400 transition-all font-mono ${errors.image ? 'border-red-300 bg-red-50' : 'border-gray-200'}`}
            />
            {errors.image && <p className="text-red-500 text-xs">{errors.image}</p>}
            {form.image && (
              <div className="mt-1 rounded-xl overflow-hidden h-32 border border-gray-100">
                <img
                  src={form.image}
                  alt="Preview del proyecto"
                  className="w-full h-full object-cover"
                  onError={(e) => {
                    ;(e.target as HTMLImageElement).style.display = 'none'
                  }}
                />
              </div>
            )}
          </div>

          {/* Category + Discipline + Year */}
          <div className="grid grid-cols-3 gap-4">
            <div className="flex flex-col gap-1.5">
              <label className="text-sm font-semibold text-gray-700">Categoria</label>
              <select
                value={form.category}
                onChange={(e) => setForm({ ...form, category: e.target.value })}
                className="border border-gray-200 rounded-xl px-3 py-3 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-teal-400 transition-all bg-white"
              >
                {CATEGORIES.map((c) => (
                  <option key={c} value={c}>{c}</option>
                ))}
              </select>
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-sm font-semibold text-gray-700">Disciplina</label>
              <select
                value={form.discipline}
                onChange={(e) => setForm({ ...form, discipline: e.target.value as Project['discipline'] })}
                className="border border-gray-200 rounded-xl px-3 py-3 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-teal-400 transition-all bg-white"
              >
                <option value="design">Diseno</option>
                <option value="data">Data</option>
                <option value="both">Ambos</option>
              </select>
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-sm font-semibold text-gray-700">Ano</label>
              <input
                type="text"
                value={form.year}
                onChange={(e) => setForm({ ...form, year: e.target.value })}
                placeholder="2024"
                maxLength={4}
                className="border border-gray-200 rounded-xl px-4 py-3 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-teal-400 transition-all"
              />
            </div>
          </div>

          {/* Tags */}
          <div className="flex flex-col gap-1.5">
            <label className="text-sm font-semibold text-gray-700">Tags</label>
            <div className="flex gap-2">
              <input
                type="text"
                value={tagInput}
                onChange={(e) => setTagInput(e.target.value)}
                onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addTag() } }}
                placeholder="Ej: Python, Figma, SQL..."
                className="flex-1 border border-gray-200 rounded-xl px-4 py-2.5 text-sm text-gray-800 focus:outline-none focus:ring-2 focus:ring-teal-400 transition-all"
              />
              <button
                type="button"
                onClick={addTag}
                className="flex items-center gap-1.5 bg-teal-50 border border-teal-200 text-teal-700 text-sm font-medium px-3.5 py-2.5 rounded-xl hover:bg-teal-100 transition-colors"
              >
                <Plus size={14} />
                Agregar
              </button>
            </div>
            {form.tags.length > 0 && (
              <div className="flex flex-wrap gap-2 mt-1">
                {form.tags.map((tag) => (
                  <span
                    key={tag}
                    className="flex items-center gap-1.5 bg-teal-50 border border-teal-100 text-teal-700 text-xs font-medium px-2.5 py-1 rounded-full"
                  >
                    <Tag size={10} />
                    {tag}
                    <button
                      type="button"
                      onClick={() => removeTag(tag)}
                      className="ml-0.5 text-teal-400 hover:text-red-400 transition-colors"
                      aria-label={`Eliminar tag ${tag}`}
                    >
                      <X size={11} />
                    </button>
                  </span>
                ))}
              </div>
            )}
          </div>

          {/* Featured toggle */}
          <label className="flex items-center gap-3 cursor-pointer select-none">
            <div
              onClick={() => setForm({ ...form, featured: !form.featured })}
              className={`relative w-11 h-6 rounded-full transition-colors duration-200 ${form.featured ? 'bg-teal-500' : 'bg-gray-200'}`}
              role="switch"
              aria-checked={form.featured}
            >
              <span
                className={`absolute top-0.5 left-0.5 w-5 h-5 rounded-full bg-white shadow transition-transform duration-200 ${form.featured ? 'translate-x-5' : 'translate-x-0'}`}
              />
            </div>
            <span className="text-sm font-medium text-gray-700">Destacado (aparece primero)</span>
          </label>

          {/* Actions */}
          <div className="flex justify-end gap-3 pt-2 border-t border-gray-100 mt-1">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 text-sm font-medium text-gray-600 hover:text-black border border-gray-200 rounded-xl hover:bg-gray-50 transition-all"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 text-sm font-semibold bg-teal-600 hover:bg-teal-500 text-white rounded-xl transition-all shadow-sm"
            >
              {initial ? 'Guardar cambios' : 'Crear proyecto'}
            </button>
          </div>
        </form>
      </div>
    </div>
  )
}
