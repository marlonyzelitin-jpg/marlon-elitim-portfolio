// ──────────────────────────────────────────────────────
//  Shared localStorage store for projects & site settings
// ──────────────────────────────────────────────────────

export interface Project {
  id: string
  title: string
  description: string
  category: string
  discipline: 'design' | 'data' | 'both'
  image: string
  tags: string[]
  year: string
  featured: boolean
  order: number
}

export interface SiteSettings {
  ownerName: string
  tagline: string
  bio: string
  email: string
  phone: string
  location: string
  availableForWork: boolean
}

// ── Auth ──────────────────────────────────────────────
const ADMIN_KEY = 'ds_admin_session'
const CREDENTIALS = { username: 'marlon', password: 'marlon2024' }

export function login(username: string, password: string): boolean {
  if (username === CREDENTIALS.username && password === CREDENTIALS.password) {
    if (typeof window !== 'undefined') {
      localStorage.setItem(ADMIN_KEY, 'true')
    }
    return true
  }
  return false
}

export function logout() {
  if (typeof window !== 'undefined') {
    localStorage.removeItem(ADMIN_KEY)
  }
}

export function isLoggedIn(): boolean {
  if (typeof window === 'undefined') return false
  return localStorage.getItem(ADMIN_KEY) === 'true'
}

// ── Projects ──────────────────────────────────────────
const PROJECTS_KEY = 'ds_projects'

const DEFAULT_PROJECTS: Project[] = [
  {
    id: '1',
    title: 'Nova Brand Identity',
    description: 'Complete rebrand for a SaaS startup — logo, typography, and design system.',
    category: 'Branding',
    discipline: 'design',
    image: 'https://images.unsplash.com/photo-1634942537034-2531766767d1?w=700&q=80',
    tags: ['Brand Strategy', 'Logo Design', 'Typography'],
    year: '2024',
    featured: true,
    order: 0,
  },
  {
    id: '2',
    title: 'Retail Sales Intelligence',
    description: 'End-to-end data pipeline and Power BI dashboard revealing $2M in hidden revenue.',
    category: 'Data Analytics',
    discipline: 'data',
    image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=700&q=80',
    tags: ['Power BI', 'SQL', 'Python', 'ETL'],
    year: '2024',
    featured: true,
    order: 1,
  },
  {
    id: '3',
    title: 'Pulse Mobile App',
    description: 'Health tracking app UI/UX with integrated analytics views — wireframes to prototype.',
    category: 'UI/UX',
    discipline: 'design',
    image: 'https://images.unsplash.com/photo-1555774698-0b77e0d5fac6?w=700&q=80',
    tags: ['Mobile UI', 'Figma', 'Prototyping', 'Data Viz'],
    year: '2024',
    featured: true,
    order: 2,
  },
  {
    id: '4',
    title: 'Customer Churn Prediction',
    description: 'ML model with 91% accuracy predicting churn, reducing attrition by 34%.',
    category: 'Data Science',
    discipline: 'data',
    image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=700&q=80',
    tags: ['Python', 'Scikit-Learn', 'Tableau', 'ML'],
    year: '2024',
    featured: false,
    order: 3,
  },
  {
    id: '5',
    title: 'Horizon Fintech Platform',
    description: 'Dashboard design for a fintech analytics platform — data-driven UI meets intuitive UX.',
    category: 'Web Design',
    discipline: 'both',
    image: 'https://images.unsplash.com/photo-1611532736597-de2d4265fba3?w=700&q=80',
    tags: ['Dashboard', 'Design System', 'Figma'],
    year: '2023',
    featured: false,
    order: 4,
  },
  {
    id: '6',
    title: 'Supply Chain Analytics',
    description: 'Real-time logistics monitoring dashboard with predictive delay alerts.',
    category: 'Data Analytics',
    discipline: 'data',
    image: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?w=700&q=80',
    tags: ['SQL', 'Looker', 'dbt', 'Forecasting'],
    year: '2023',
    featured: false,
    order: 5,
  },
]

export function getProjects(): Project[] {
  if (typeof window === 'undefined') return DEFAULT_PROJECTS
  try {
    const raw = localStorage.getItem(PROJECTS_KEY)
    if (!raw) {
      localStorage.setItem(PROJECTS_KEY, JSON.stringify(DEFAULT_PROJECTS))
      return DEFAULT_PROJECTS
    }
    return JSON.parse(raw) as Project[]
  } catch {
    return DEFAULT_PROJECTS
  }
}

export function saveProjects(projects: Project[]) {
  if (typeof window === 'undefined') return
  localStorage.setItem(PROJECTS_KEY, JSON.stringify(projects))
}

export function createProject(data: Omit<Project, 'id' | 'order'>): Project {
  const projects = getProjects()
  const project: Project = {
    ...data,
    id: crypto.randomUUID(),
    order: projects.length,
  }
  saveProjects([...projects, project])
  return project
}

export function updateProject(id: string, data: Partial<Project>): Project | null {
  const projects = getProjects()
  const idx = projects.findIndex((p) => p.id === id)
  if (idx === -1) return null
  projects[idx] = { ...projects[idx], ...data }
  saveProjects(projects)
  return projects[idx]
}

export function deleteProject(id: string): boolean {
  const projects = getProjects()
  const filtered = projects.filter((p) => p.id !== id)
  if (filtered.length === projects.length) return false
  saveProjects(filtered)
  return true
}

// ── Site Settings ─────────────────────────────────────
const SETTINGS_KEY = 'ds_settings'

const DEFAULT_SETTINGS: SiteSettings = {
  ownerName: 'Marlon Elitim',
  tagline: 'Design Meets Data Intelligence',
  bio: "Soy diseñador creativo y analista de datos con experiencia ayudando a marcas a encontrar su identidad visual y tomar mejores decisiones basadas en datos.",
  email: 'contacto@marlonelitim.com',
  phone: '+1 (555) 000-0000',
  location: 'Remote — Worldwide',
  availableForWork: true,
}

export function getSettings(): SiteSettings {
  if (typeof window === 'undefined') return DEFAULT_SETTINGS
  try {
    const raw = localStorage.getItem(SETTINGS_KEY)
    if (!raw) {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(DEFAULT_SETTINGS))
      return DEFAULT_SETTINGS
    }
    return JSON.parse(raw) as SiteSettings
  } catch {
    return DEFAULT_SETTINGS
  }
}

export function saveSettings(settings: SiteSettings) {
  if (typeof window === 'undefined') return
  localStorage.setItem(SETTINGS_KEY, JSON.stringify(settings))
}
